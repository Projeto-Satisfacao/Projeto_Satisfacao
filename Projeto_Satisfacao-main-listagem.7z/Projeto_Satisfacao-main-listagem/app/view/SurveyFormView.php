<?php

/**
 * Classe responsável pelos dados do formulário de criação ou edição de uma avaliação e seus detalhes
 */

class SurveyFormView {

  /**
  * Exibe o formulário para avaliação de um setor
  */
  public function displaySurveyForm() {
      // Código do método
  }
  
  /**
  * Envia os dados da avaliação para o controlador
  * @return array - Dados da avaliação
  */
  public function getSurveyFormData() {
      // Código do método
  }
  
}

